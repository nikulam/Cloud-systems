def xprint(*args, **kwargs):
    print("STUDENT_LOG: " + " ".join(map(str, args)), **kwargs)
