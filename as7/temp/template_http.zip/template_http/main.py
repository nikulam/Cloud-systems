import os
import tempfile    # To create temporary file before uploading to bucket
from google.cloud import storage
# Add any imports that you may need, but make sure to update requirements.txt


def create_text_file_http(request):
	# TODO: Add logic here

    return